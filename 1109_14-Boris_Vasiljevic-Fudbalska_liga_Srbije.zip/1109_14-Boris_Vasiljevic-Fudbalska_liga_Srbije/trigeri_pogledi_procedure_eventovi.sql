USE db_fudbalska_liga_srbije ;
-- pogledi
create view fudbaleri as
select JMB, Ime, Prezime, BrojNaDresu, IdKluba from igrac natural join osoba
order by Prezime;
 create view fudbaleri_u_klubu as
 select f.IdKluba, Ime, Prezime, BrojNaDresu, fk.NazivKluba from fudbaleri f inner join  fudbalski_klub fk  on f.IdKluba=fk.IdKluba order by f.IdKluba;
create view sudije_u_ligi as
select JMB,Ime,Prezime from sudija natural join osoba;
create view treneri_u_ligi as
select IdKluba,JMB,Ime,Prezime from trener natural join osoba;
create view treneri_treniraju_klubove as
select Ime,Prezime,fk.NazivKluba from treneri_u_ligi t inner join fudbalski_klub fk on t.IdKluba=fk.IdKluba order by fk.IdKluba;
-- procedure

DELIMITER //
CREATE PROCEDURE kreiranje_utakmice(
  id INT, idd INT, idg INT,vrijeme DATETIME,brkola INT)
BEGIN
START TRANSACTION;
   INSERT INTO utakmica(IdUtakmice, IdKlubaD, IdKlubaG, VrijemeOdigravanaja,BrojKola) 
     VALUES(id, idd, idg, vrijeme, brkola);
COMMIT;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE kreiranje_detalja_utakmice(
  idu INT, JMBG CHAR(13), vrijemeod TINYINT,vrijemedo TINYINT)
BEGIN
START TRANSACTION;
   INSERT INTO detalji_utakmice(IdUtakmice, JMB, IgraOdMinute, IgraoDoMinute) 
     VALUES(idu,JMBG,vrijemeod,vrijemedo);
COMMIT;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE kreiranje_dogadjaja_utakmice(
  idd INT, idu INT, JMBG CHAR(13), mindog TIME)
BEGIN
START TRANSACTION;
   INSERT INTO dogadjaj(IdDogadjaja,IdUtakmice, JMB,MinutDogadjaja) 
     VALUES(idd,idu,JMBG,mindog);
COMMIT;
END//
DELIMITER ;
-- event
DELIMITER //
CREATE 
    EVENT obrisi_igraca_iz_kluba    
    ON SCHEDULE EVERY 1 DAY STARTS '2021-06-20 00:00:00' 
    DO  BEGIN
    SELECT datumIstekaUgovora,IdUgovora from ugovor u;
    SELECT IdUgovora,JMB from igrac_ugovor iu;
    if (u.datumIstekaUgovora<'2021-06-20 00:00:00')then
    DELETE FROM igrac_ugovor WHERE IdUgovora=iu.IdUgovora;
    DELETE FROM ugovor WHERE IdUgovora = u.IdUgovora;
    DELETE FROM igrac WHERE JMB=iu.JMB;
	end if;
    END//
DELIMITER ;
drop trigger izmjene_na_utakmici;
DELIMITER //
create trigger izmjene_na_utakmici before insert on ima
	for each row
    begin
		if  (new.IdDogadjaja = 1) then
			update utakmica 
            set BrojGolovaDomacin=BrojGolovaDomacin+1
            where IdUtakmice=new.IdUtakmice;
            update igrac
            set BrojDatihGolova=BrojDatihGolova+1
            where JMB=new.JMB;
            else if(new.IdDogadjaja=2) then
            update igrac
            set BrojZutihKartona=BrojZutihKartona+1
            where JMB=new.JMB;
            else if(new.IdDogadjaja=3) then
            update igrac
            set BrojCrvenihKartona=BrojCrvenihKartona+1
            where JMB=new.JMB;
            else if(new.IdDogadjaja=4) then
            update utakmica
            set BrojGolovaGost=BrojGolovaGost+1
            where IdUtakmice=new.IdUtakmice;
            update igrac
            set BrojDatihGolova=BrojDatihGolova+1
            where JMB=new.JMB;
            else if(new.IdDogadjaja=5) then
            update igrac
            set BrojAsistencija=BrojAsistencija+1
            where JMB=new.JMB;
		end if;
		end if;
		end if;
        end if;
        end if;
    end;//
DELIMITER ;
create user 'boris'@'localhost' IDENTIFIED WITH mysql_native_password BY 'boris';
grant all privileges on db_fudbalska_liga_srbije.* to 'boris'@'localhost';

