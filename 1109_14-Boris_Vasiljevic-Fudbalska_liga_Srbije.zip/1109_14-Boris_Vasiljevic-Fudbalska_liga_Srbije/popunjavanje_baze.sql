use db_fudbalutakmicaska_liga_srbije;
insert into mjesto values(1,'Beograd');
insert into lokacija values('Humska 1',1);
insert into fudbalski_klub values(1,'Partizan','Stadion Partizana',1,'Humska 1',0,0,0,1);
insert into lokacija values('Čukarica 1',1);
insert into fudbalski_klub values(2,'Čukarički','Banovo brdo',1,'Čukarica 1',0,0,0,2);
insert into mjesto values(2,'Novi Sad');
insert into lokacija values('Bulevar Oslobođenja',2);
insert into fudbalski_klub values(3,'Vojvodina','Karađorđe',2,'Bulevar Oslobođenja',0,0,0,3);
insert into mjesto values(3,'Bačka Topola');
insert into lokacija values('Topola 1',3);
insert into fudbalski_klub values(4,'TSC','Gradski stadion',3,'Topola 1',0,0,0,4);

insert into drzava values(1,'Srbija');
insert into drzava values(2,'Crna Gora');
insert into drzava values(3,'Izrael');
insert into drzava values(4,'Gvineja');
insert into drzava values(5,'Francuska');
insert into drzava values(6,'Mađarska');
insert into drzava values(7,'Bosna i Hercegovina');
insert into drzava values(8,'Hrvatska');

insert into osoba values('2709999123456','Popović','Aleksandar','1999-09-27',1);
insert into osoba values('2507988123456','Obradović','Ivan','1988-07-25',1);
insert into osoba values('2602990123456','Miljković','Aleksandar','1988-07-25',1);
insert into osoba values('0808994123456','Vujačić','Igor','1994-08-08',2);
insert into osoba values('1202984123456','Ostojić','Bojan','1984-02-12',1);
insert into osoba values('2003995123456','Zdjelar','Saša','1995-03-20',1);
insert into osoba values('1106991123456','Suma','Sejduba','1991-06-11',4);
insert into osoba values('0203994123456','Marković','Lazar','1994-03-02',1);
insert into osoba values('0808002123456','Jović','Nemanja','2002-08-08',1);
insert into osoba values('0809001123456','Štulić','Nikola','2001-09-08',1);
insert into osoba values('2807983123456','Stojković','Vladimir','1983-07-28',1);
insert into osoba values('1504994123456','Urošević','Slobodan','1994-04-15',1);
insert into osoba values('1903992123456','Jojić','Miloš','1992-03-19',1);
insert into osoba values('2707994123456','Holender','Filip','1994-07-27',6);
insert into osoba values('0109993123456','Bahebeck','Jan','1993-09-01',5);

insert into osoba values('2404987222222','Belić','Nemanja','1987-04-24',1);
insert into osoba values('0410002222222','Drezgić','Uroš','2002-04-10',1);
insert into osoba values('0508002222222','Ergelaš','Mitar','2002-08-05',1);
insert into osoba values('1607000222222','Kamenović','Dimitrije','2000-07-16',1);
insert into osoba values('0308991222222','Ostojić','Miloš','1991-08-03',1);
insert into osoba values('2404993222222','Docić','Marko','1993-04-28',1);
insert into osoba values('1401999222222','Kovač','Stefan','1999-01-14',7);
insert into osoba values('2410996222222','Pantić','Danilo','1996-10-26',1);
insert into osoba values('2102001222222','Vidosavljević','Milutin','2001-02-21',1);
insert into osoba values('1502999222222','Jovanović','Đorđe','2000-04-25',2);
insert into osoba values('2504000222222','Rakonjac','Marko','1999-10-08',1);
insert into osoba values('0810999222222','Petrović','Đorđe','1985-07-13',1);
insert into osoba values('1307885222222','Puškarić','Darko','2003-03-16',1);
insert into osoba values('1603003222222','Grgić','Dario','2002-01-20',1);
insert into osoba values('2001002222222','Lukić','Jovan','2002-01-20',1);
insert into osoba values('2111002222222','Spasojević','Mihajlo','2002-11-21',1);

insert into osoba values('2112996333333','Simić','Nikola','1996-12-21',1);
insert into osoba values('0203995333333','Stojković','Aranđel','1995-03-02',1);
insert into osoba values('2404995333333','Saničanin','Siniša','1995-04-24',7);
insert into osoba values('1512992333333','Bralić','Slavko','1992-12-15',8);
insert into osoba values('1203999333333','Devetak','Mladen','1999-03-12',1);
insert into osoba values('0409991333333','Bojić','Petar','1991-09-04',1);
insert into osoba values('0709984333333','Drinčić','Nikola','1998-09-07',2);
insert into osoba values('0705001333333','Zukić','Dejan','2001-05-07',1);
insert into osoba values('2712991333333','Vukadinović','Miljan','1991-12-27',1);
insert into osoba values('0508000133333','Topić','Mirko','2000-08-05',1);
insert into osoba values('1806991333333','Čović','Nemanja','1991-06-18',1);
insert into osoba values('2610000333333','Toroman','Nemanja','2000-10-26',1);
insert into osoba values('2305992333333','Andrić','Nikola','1992-05-23',1);
insert into osoba values('1702995333333','Simić','Veljko','1995-02-17',1);
insert into osoba values('2512999333333','Gemović','Miodrag','1999-12-25',1);
insert into osoba values('2109990333333','Mrkaić','Momčilo','1999-09-21',7);

insert into osoba values('2404987444444','Filipović','Nenad','1987-04-24',1);
insert into osoba values('0311990444444','Antonić','Goran','1990-03-11',1);
insert into osoba values('2705995444444','Babić','Filip','1995-05-27',1);
insert into osoba values('0501001444444','Balaž','Bojan','2001-01-05',1);
insert into osoba values('0309992444444','Petković','Marko','1992-09-03',1);
insert into osoba values('1011999444444','Banjac','Mihajlo','1994-11-10',1);
insert into osoba values('1003992444444','Miličević','Dejan','1992-03-10',1);
insert into osoba values('2009989444444','Tomanović','Saša','1989-09-20',1);
insert into osoba values('2409997444444','Duronjić','Borko','1997-09-24',1);
insert into osoba values('0205992444444','Lukić','Nenad','1992-05-02',1);
insert into osoba values('0603990444444','Zec','Đuro','1990-03-06',1);
insert into osoba values('0704988444444','Jorgić','Nemanja','1988-04-07',1);
insert into osoba values('1704992444444','Petrović','Nemanja','1992-04-17',1);
insert into osoba values('1401985444444','Tumbasević','Janko','1985-01-14',2);
insert into osoba values('2907999444444','Stanojev','Jug','1999-07-29',1);
insert into osoba values('0908999444444','Tomašević','Nemanja','1999-08-09',1);

insert into pozicija_igraca values('Golman',1);
insert into pozicija_igraca values('Desni bek',2);
insert into pozicija_igraca values('Lijevi bek',3);
insert into pozicija_igraca values('Štoper',4);
insert into pozicija_igraca values('Zadnji vezni',5);
insert into pozicija_igraca values('Centralni vezni',6);
insert into pozicija_igraca values('Prednji vezni',7);
insert into pozicija_igraca values('Lijevo krilo',8);
insert into pozicija_igraca values('Desno krilo',9);
insert into pozicija_igraca values('Napadač',10);

insert into igrac values('2709999123456',41,'R ',1,1);
insert into igrac values('2507988123456',37,'L ',3,1);
insert into igrac values('2602990123456',26,'R ',2,1);
insert into igrac values('0808994123456',5,'R ',4,1);
insert into igrac values('1202984123456',23,'RL',4,1);
insert into igrac values('2003995123456',16,'R ',5,1);
insert into igrac values('1802988123456',6,'R ',6,1);
insert into igrac values('1106991123456',20,'RL',7,1);
insert into igrac values('0203994123456',50,'RL',9,1);
insert into igrac values('0808002123456',77,'R ',8,1);
insert into igrac values('0809001123456',32,'R ',10,1);
insert into igrac values('2807983123456',88,'R ',1,1);
insert into igrac values('1504994123456',72,'L ',3,1);
insert into igrac values('1903992123456',39,'R ',6,1);
insert into igrac values('2707994123456',8,'RL',10,1);
insert into igrac values('0109993123456',9,'R ',10,1);

insert into igrac values('2404987222222',1,'R ',1,2);
insert into igrac values('0410002222222',26,'RL',3,2);
insert into igrac values('0508002222222',14,'R ',2,2);
insert into igrac values('1607000222222',16,'R ',4,2);
insert into igrac values('0308991222222',40,'L ',4,2);
insert into igrac values('2404993222222',5,'R ',5,2);
insert into igrac values('1401999222222',77,'R ',5,2);
insert into igrac values('2410996222222',55,'RL',5,2);
insert into igrac values('2102001222222',10,'R ',8,2);
insert into igrac values('1502999222222',9,'L ',9,2);
insert into igrac values('2504000222222',7,'L ',10,2);
insert into igrac values('0810999222222',12,'R ',1,2);
insert into igrac values('1307885222222',21,'R ',4,2);
insert into igrac values('1603003222222',51,'RL',7,2);
insert into igrac values('2001002222222',88,'R ',8,2);
insert into igrac values('2111002222222',28,'L ',10,2);

insert into igrac values('2112996333333',25,'L ',1,3);
insert into igrac values('0203995333333',30,'R ',2,3);
insert into igrac values('2404995333333',5,'R ',4,3);
insert into igrac values('1512992333333',29,'L ',4,3);
insert into igrac values('1203999333333',3,'RL',3,3);
insert into igrac values('0409991333333',24,'RL',5,3);
insert into igrac values('0709984333333',18,'RL',5,3);
insert into igrac values('0705001333333',10,'L ',7,3);
insert into igrac values('2712991333333',90,'L ',8,3);
insert into igrac values('0508000133333',8,'R ',9,3);
insert into igrac values('1806991333333',7,'R ',10,3);
insert into igrac values('2610000333333',32,'R ',1,3);
insert into igrac values('2305992333333',15,'R ',4,3);
insert into igrac values('1702995333333',21,'L ',6,3);
insert into igrac values('2512999333333',28,'RL',10,3);
insert into igrac values('2109990333333',23,'L ',10,3);

insert into igrac values('2404987444444',1,'R ',1,4);
insert into igrac values('0311990444444',17,'R ',2,4);
insert into igrac values('2705995444444',18,'R ',1,4);
insert into igrac values('0501001444444',26,'R ',1,4);
insert into igrac values('0309992444444',33,'L ',3,4);
insert into igrac values('1011999444444',14,'RL',6,4);
insert into igrac values('1003992444444',8,'RL',6,4);
insert into igrac values('2009989444444',6,'R ',6,4);
insert into igrac values('2409997444444',20,'L ',8,4);
insert into igrac values('0205992444444',27,'R ',9,4);
insert into igrac values('0603990444444',10,'R ',10,4);
insert into igrac values('0704988444444',23,'R ',1,4);
insert into igrac values('1704992444444',30,'L ',4,4);
insert into igrac values('1401985444444',7,'R ',6,4);
insert into igrac values('2907999444444',19,'R ',9,4);
insert into igrac values('0908999444444',34,'L ',8,4);

insert into osoba values('2212977333333','Lalatović','Nenad','1977-12-22',1);
insert into osoba values('2810973123456','Stanojević','Aleksandar','1973-10-28',1);
insert into osoba values('2304977033333','Đorđević','Dušan','1970-04-23',1);
insert into osoba values('0403977433333','Krstajić','Mladen','1974-03-04',1);

insert into trener values('2212977333333',3);
insert into trener values('2810973123456',1);
insert into trener values('2304977033333',2);
insert into trener values('0403977433333',4);

insert into osoba values('1111111111111','Srđan','Jovanović','1980-01-01',1);
insert into osoba values('2222222222222','Novak','Simović','1980-01-02',1);
insert into sudija values('1111111111111');
insert into sudija values('2222222222222');
insert into osoba values('3333333333333','Ristić','Milovan','1980-01-03',1);
insert into osoba values('4444444444444','Đurđević','Dalibor','1980-01-04',1);
insert into osoba values('5555555555555','Minić','Milan','1980-01-05',1);
insert into osoba values('6666666666666','Bogićević','Dragan','1980-01-06',1);
insert into sudija values('3333333333333');
insert into sudija values('4444444444444');
insert into sudija values('5555555555555');
insert into sudija values('6666666666666');

insert into tip_dogadjaja values(1,'postignut gol');
insert into tip_dogadjaja values(2,'žuti karton');
insert into tip_dogadjaja values(3,'crveni karton');
insert into tip_dogadjaja values(4,'primljen gol');
insert into tip_dogadjaja values(5,'napravljen faul');
insert into tip_dogadjaja values(6,'asistencija');
insert into tip_dogadjaja values(7,'gol iz penala');
insert into tip_dogadjaja values(8,'odbranjen penal');

insert into nalog values(1,'administrator','administrator');
insert into nalog values(2,'korisnik','korisnik');

insert into ugovor values(11,'2020-07-01','2023-07-01','350k',1);
insert into ugovor values(12,'2020-07-01','2023-07-01','450k',1);
insert into ugovor values(13,'2020-07-01','2023-07-01','450k',1);
insert into ugovor values(14,'2020-07-01','2023-07-01','750k',1);
insert into ugovor values(15,'2020-07-01','2023-07-01','990k',1);
insert into ugovor values(16,'2020-07-01','2023-07-01','1m',1);
insert into ugovor values(17,'2020-07-01','2023-07-01','2mk',1);
insert into ugovor values(18,'2020-07-01','2023-07-01','750k',1);
insert into ugovor values(19,'2020-07-01','2023-07-01','350k',1);
insert into ugovor values(110,'2020-07-01','2023-07-01','150k',1);
insert into ugovor values(111,'2020-07-01','2023-07-01','750k',1);
insert into ugovor values(112,'2020-07-01','2023-07-01','1.5m',1);
insert into ugovor values(113,'2020-07-01','2023-07-01','300k',1);
insert into ugovor values(114,'2020-07-01','2023-07-01','100k',1);
insert into ugovor values(115,'2020-07-01','2023-07-01','550k',1);
insert into ugovor values(116,'2020-07-01','2023-07-01','1m',1);
insert into ugovor values(117,'2020-07-01','2023-07-01','500k',1);


insert into ugovor values(21,'2020-07-01','2023-07-01','350k',2);
insert into ugovor values(22,'2020-07-01','2023-07-01','450k',2);
insert into ugovor values(23,'2020-07-01','2023-07-01','450k',2);
insert into ugovor values(24,'2020-07-01','2023-07-01','750k',2);
insert into ugovor values(25,'2020-07-01','2023-07-01','990k',2);
insert into ugovor values(26,'2020-07-01','2023-07-01','1m',2);
insert into ugovor values(27,'2020-07-01','2023-07-01','2mk',2);
insert into ugovor values(28,'2020-07-01','2023-07-01','750k',2);
insert into ugovor values(29,'2020-07-01','2023-07-01','350k',2);
insert into ugovor values(210,'2020-07-01','2023-07-01','150k',2);
insert into ugovor values(211,'2020-07-01','2023-07-01','750k',2);
insert into ugovor values(212,'2020-07-01','2023-07-01','1.5m',2);
insert into ugovor values(213,'2020-07-01','2023-07-01','300k',2);
insert into ugovor values(214,'2020-07-01','2023-07-01','100k',2);
insert into ugovor values(215,'2020-07-01','2023-07-01','550k',2);
insert into ugovor values(216,'2020-07-01','2023-07-01','1m',2);
insert into ugovor values(217,'2020-07-01','2023-07-01','500k',2);


insert into ugovor values(31,'2020-07-01','2023-07-01','350k',3);
insert into ugovor values(32,'2020-07-01','2023-07-01','450k',3);
insert into ugovor values(33,'2020-07-01','2023-07-01','450k',3);
insert into ugovor values(34,'2020-07-01','2023-07-01','750k',3);
insert into ugovor values(35,'2020-07-01','2023-07-01','990k',3);
insert into ugovor values(36,'2020-07-01','2023-07-01','1m',3);
insert into ugovor values(37,'2020-07-01','2023-07-01','2mk',3);
insert into ugovor values(38,'2020-07-01','2023-07-01','750k',3);
insert into ugovor values(39,'2020-07-01','2023-07-01','350k',3);
insert into ugovor values(310,'2020-07-01','2023-07-01','150k',3);
insert into ugovor values(311,'2020-07-01','2023-07-01','750k',3);
insert into ugovor values(312,'2020-07-01','2023-07-01','1.5m',3);
insert into ugovor values(313,'2020-07-01','2023-07-01','300k',3);
insert into ugovor values(314,'2020-07-01','2023-07-01','100k',3);
insert into ugovor values(315,'2020-07-01','2023-07-01','550k',3);
insert into ugovor values(316,'2020-07-01','2023-07-01','1m',3);
insert into ugovor values(317,'2020-07-01','2023-07-01','500k',3);

insert into ugovor values(41,'2020-07-01','2023-07-01','350k',4);
insert into ugovor values(42,'2020-07-01','2023-07-01','450k',4);
insert into ugovor values(43,'2020-07-01','2023-07-01','450k',4);
insert into ugovor values(44,'2020-07-01','2023-07-01','750k',4);
insert into ugovor values(45,'2020-07-01','2023-07-01','990k',4);
insert into ugovor values(46,'2020-07-01','2023-07-01','1m',4);
insert into ugovor values(47,'2020-07-01','2023-07-01','2mk',4);
insert into ugovor values(48,'2020-07-01','2023-07-01','750k',4);
insert into ugovor values(49,'2020-07-01','2023-07-01','350k',4);
insert into ugovor values(410,'2020-07-01','2023-07-01','150k',4);
insert into ugovor values(411,'2020-07-01','2023-07-01','750k',4);
insert into ugovor values(412,'2020-07-01','2023-07-01','1.5m',4);
insert into ugovor values(413,'2020-07-01','2023-07-01','300k',4);
insert into ugovor values(414,'2020-07-01','2023-07-01','100k',4);
insert into ugovor values(415,'2020-07-01','2023-07-01','550k',4);
insert into ugovor values(416,'2020-07-01','2023-07-01','1m',4);
insert into ugovor values(417,'2020-07-01','2023-07-01','500k',4);

insert into ugovor_igrac values(11,'2709999123456');
insert into ugovor_igrac values(12,'2507988123456');
insert into ugovor_igrac values(13,'2602990123456');
insert into ugovor_igrac values(14,'0808994123456');
insert into ugovor_igrac values(15,'1202984123456');
insert into ugovor_igrac values(16,'2003995123456');
insert into ugovor_igrac values(17,'1106991123456');
insert into ugovor_igrac values(18,'0203994123456');
insert into ugovor_igrac values(19,'0808002123456');
insert into ugovor_igrac values(110,'0809001123456');
insert into ugovor_igrac values(111,'2807983123456');
insert into ugovor_igrac values(112,'1504994123456');
insert into ugovor_igrac values(113,'1903992123456');
insert into ugovor_igrac values(114,'2707994123456');
insert into ugovor_igrac values(115,'0109993123456');
insert into ugovor_igrac values(116,'1802988123456');

insert into ugovor_igrac values(21,'2404987222222');
insert into ugovor_igrac values(22,'0410002222222');
insert into ugovor_igrac values(23,'0508002222222');
insert into ugovor_igrac values(24,'1607000222222');
insert into ugovor_igrac values(25,'0308991222222');
insert into ugovor_igrac values(26,'2404993222222');
insert into ugovor_igrac values(27,'1401999222222');
insert into ugovor_igrac values(28,'2410996222222');
insert into ugovor_igrac values(29,'2102001222222');
insert into ugovor_igrac values(210,'1502999222222');
insert into ugovor_igrac values(211,'2504000222222');
insert into ugovor_igrac values(212,'0810999222222');
insert into ugovor_igrac values(213,'1307885222222');
insert into ugovor_igrac values(214,'1603003222222');
insert into ugovor_igrac values(215,'2001002222222');
insert into ugovor_igrac values(216,'2111002222222');

insert into ugovor_igrac values(31,'2112996333333');
insert into ugovor_igrac values(32,'0203995333333');
insert into ugovor_igrac values(33,'2404995333333');
insert into ugovor_igrac values(34,'1512992333333');
insert into ugovor_igrac values(35,'1203999333333');
insert into ugovor_igrac values(36,'0409991333333');
insert into ugovor_igrac values(37,'0709984333333');
insert into ugovor_igrac values(38,'0705001333333');
insert into ugovor_igrac values(39,'2712991333333');
insert into ugovor_igrac values(310,'0508000133333');
insert into ugovor_igrac values(311,'1806991333333');
insert into ugovor_igrac values(312,'2610000333333');
insert into ugovor_igrac values(313,'2305992333333');
insert into ugovor_igrac values(314,'1702995333333');
insert into ugovor_igrac values(315,'2512999333333');
insert into ugovor_igrac values(316,'2109990333333');

insert into ugovor_igrac values(41,'2404987444444');
insert into ugovor_igrac values(42,'0311990444444');
insert into ugovor_igrac values(43,'2705995444444');
insert into ugovor_igrac values(44,'0501001444444');
insert into ugovor_igrac values(45,'0309992444444');
insert into ugovor_igrac values(46,'1011999444444');
insert into ugovor_igrac values(47,'1003992444444');
insert into ugovor_igrac values(48,'2009989444444');
insert into ugovor_igrac values(49,'2409997444444');
insert into ugovor_igrac values(410,'0205992444444');
insert into ugovor_igrac values(411,'0603990444444');
insert into ugovor_igrac values(412,'0704988444444');
insert into ugovor_igrac values(413,'1704992444444');
insert into ugovor_igrac values(414,'1401985444444');
insert into ugovor_igrac values(415,'2907999444444');
insert into ugovor_igrac values(416,'0908999444444');

insert into ugovor_trener values(117,'2810973123456');
insert into ugovor_trener values(217,'2304977033333');
insert into ugovor_trener values(317,'2212977333333');
insert into ugovor_trener values(417,'0403977433333');

delete from dogadjaj where IdDogadjaja=2;
insert into detalji_utakmice values(1,'0809001123456',1,90);
insert into detalji_utakmice values(1,'0808002123456',1,90);
insert into detalji_utakmice values(1,'0203994123456',1,90);
insert into detalji_utakmice values(1,'2003995123456',1,90);
insert into detalji_utakmice values(1,'2410996222222',1,90);
insert into dogadjaj values(1,23);
insert into dogadjaj values(1,42);
insert into dogadjaj values(6,42);
insert into dogadjaj values(2,'15:25:00');
insert into dogadjaj values(2,'17:05:00');
insert into ima values(1,'0809001123456',1);
insert into ima values(1,'0808002123456',1);
insert into ima values(1,'0203994123456',6);
insert into ima values(1,'2003995123456',2);
insert into ima values(1,'2410996222222',2);

insert into detalji_utakmice values(2,'2712991333333',1,90);
insert into detalji_utakmice values(2,'1003992444444',1,90);
insert into dogadjaj values(1,'17:20:00');
insert into dogadjaj values(2,'18:10:00');
insert into ima values(2,'2712991333333',1);
insert into ima values(2,'1003992444444',2);
update utakmica
set brojGolovaDomacin=2
where IdUtakmice=1 and brojKola=1;
update utakmica
set brojGolovaGost=0
where IdUtakmice=1 and brojKola=1;
update utakmica
set brojGolovaDomacin=1
where IdUtakmice=2 and brojKola=1;
update utakmica
set brojGolovaGost=0
where IdUtakmice=2 and brojKola=1;
update utakmica
set brojGolovaDomacin=0
where IdUtakmice=3 and brojKola=2;
update utakmica
set brojGolovaGost=0
where IdUtakmice=3 and brojKola=2;
update utakmica
set brojGolovaDomacin=0
where IdUtakmice=4 and brojKola=2;
update utakmica
set brojGolovaGost=1
where IdUtakmice=4 and brojKola=2;
update utakmica
set brojGolovaDomacin=3
where IdUtakmice=5 and brojKola=3;
update utakmica
set brojGolovaGost=1
where IdUtakmice=5 and brojKola=3;
update utakmica
set brojGolovaDomacin=0
where IdUtakmice=6 and brojKola=3;
update utakmica
set brojGolovaGost=0
where IdUtakmice=6 and brojKola=3;