-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema db_fudbalska_liga_srbije
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema db_fudbalska_liga_srbije
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `db_fudbalska_liga_srbije` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
USE `db_fudbalska_liga_srbije` ;

-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`DRZAVA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`DRZAVA` (
  `IdDrzave` INT NOT NULL,
  `Naziv` VARCHAR(20) NULL,
  PRIMARY KEY (`IdDrzave`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`OSOBA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`OSOBA` (
  `JMB` CHAR(13) NOT NULL,
  `Prezime` VARCHAR(20) NOT NULL,
  `Ime` VARCHAR(20) NOT NULL,
  `DatumRodjenja` DATE NOT NULL,
  `IdDrzave` INT NOT NULL,
  PRIMARY KEY (`JMB`),
  INDEX `fk_drzava_osoba_idx` (`IdDrzave` ASC) VISIBLE,
  CONSTRAINT `fk_drzava_osoba`
    FOREIGN KEY (`IdDrzave`)
    REFERENCES `db_fudbalska_liga_srbije`.`DRZAVA` (`IdDrzave`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`MJESTO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`MJESTO` (
  `IdMjesto` INT NOT NULL,
  `Naziv` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`IdMjesto`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`LOKACIJA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`LOKACIJA` (
  `Adresa` VARCHAR(20) NOT NULL,
  `IdMjesto` INT NOT NULL,
  PRIMARY KEY (`Adresa`, `IdMjesto`),
  INDEX `fk_mjesto_lokacija_idx` (`IdMjesto` ASC) VISIBLE,
  CONSTRAINT `fk_mjesto_lokacija`
    FOREIGN KEY (`IdMjesto`)
    REFERENCES `db_fudbalska_liga_srbije`.`MJESTO` (`IdMjesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (
  `IdKluba` INT NOT NULL,
  `NazivKluba` VARCHAR(20) NOT NULL,
  `NazivStadiona` VARCHAR(20) NOT NULL,
  `IdMjesto` INT NOT NULL,
  `Adresa` VARCHAR(20) NOT NULL,
  `BrojPostignutihGolova` INT NOT NULL,
  `BrojPrimljenihGolova` INT NOT NULL,
  `BrojOdigranihUtakmica` INT NOT NULL,
  `PozicijaNaTabeli` INT NOT NULL,
  PRIMARY KEY (`IdKluba`),
  INDEX `fk_klub_lokacija_idx` (`IdMjesto` ASC, `Adresa` ASC) VISIBLE,
  CONSTRAINT `fk_klub_lokacija`
    FOREIGN KEY (`IdMjesto` , `Adresa`)
    REFERENCES `db_fudbalska_liga_srbije`.`LOKACIJA` (`IdMjesto` , `Adresa`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`TRENER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`TRENER` (
  `JMB` CHAR(13) NOT NULL,
  `IdKluba` INT NOT NULL,
  PRIMARY KEY (`JMB`, `IdKluba`),
  INDEX `fk_TRENER_FUDBALSKI_KLUB1_idx` (`IdKluba` ASC) VISIBLE,
  CONSTRAINT `fk_TRENER_OSOBA`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`OSOBA` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TRENER_FUDBALSKI_KLUB1`
    FOREIGN KEY (`IdKluba`)
    REFERENCES `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (`IdKluba`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`POZICIJA_IGRACA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`POZICIJA_IGRACA` (
  `NazivPozicije` VARCHAR(20) NOT NULL,
  `IdPozicijaIgraca` INT NOT NULL,
  PRIMARY KEY (`IdPozicijaIgraca`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`IGRAC`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`IGRAC` (
  `JMB` CHAR(13) NOT NULL,
  `BrojNaDresu` INT NOT NULL,
  `NogaKojomSeBoljeSluzi` CHAR(2) NOT NULL,
  `IdPozicijaIgraca` INT NOT NULL,
  `IdKluba` INT NOT NULL,
  PRIMARY KEY (`JMB`),
  INDEX `fk_igrac_pozicijaIgraca_idx` (`IdPozicijaIgraca` ASC) VISIBLE,
  INDEX `fk_IGRAC_FUDBALSKI_KLUB1_idx` (`IdKluba` ASC) VISIBLE,
  CONSTRAINT `fk_IGRAC_OSOBA1`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`OSOBA` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_igrac_pozicijaIgraca`
    FOREIGN KEY (`IdPozicijaIgraca`)
    REFERENCES `db_fudbalska_liga_srbije`.`POZICIJA_IGRACA` (`IdPozicijaIgraca`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_IGRAC_FUDBALSKI_KLUB1`
    FOREIGN KEY (`IdKluba`)
    REFERENCES `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (`IdKluba`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`SUDIJA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`SUDIJA` (
  `JMB` CHAR(13) NOT NULL,
  PRIMARY KEY (`JMB`),
  CONSTRAINT `fk_SUDIJA_OSOBA1`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`OSOBA` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`POZICIJA_SUDIJE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`POZICIJA_SUDIJE` (
  `NazivPozicije` VARCHAR(20) NOT NULL,
  `IdPozicijeSudije` INT NOT NULL,
  PRIMARY KEY (`IdPozicijeSudije`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`UGOVOR`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`UGOVOR` (
  `IdUgovora` INT NOT NULL,
  `DatumPotpisivanjaUgovora` DATE NOT NULL,
  `DatumIstekaUgovora` DATE NOT NULL,
  `Cijena` REAL NOT NULL,
  `IdKluba` INT NOT NULL,
  PRIMARY KEY (`IdUgovora`),
  INDEX `fk_klub_ugovor_idx` (`IdKluba` ASC) VISIBLE,
  CONSTRAINT `fk_klub_ugovor`
    FOREIGN KEY (`IdKluba`)
    REFERENCES `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (`IdKluba`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`UGOVOR_TRENER`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`UGOVOR_TRENER` (
  `IdUgovora` INT NOT NULL,
  `JMB` CHAR(13) NOT NULL,
  PRIMARY KEY (`IdUgovora`, `JMB`),
  INDEX `fk_UGOVOR_TRENER_UGOVOR1_idx` (`IdUgovora` ASC) VISIBLE,
  INDEX `fk_UGOVOR_TRENER_TRENER1_idx` (`JMB` ASC) VISIBLE,
  CONSTRAINT `fk_UGOVOR_TRENER_UGOVOR1`
    FOREIGN KEY (`IdUgovora`)
    REFERENCES `db_fudbalska_liga_srbije`.`UGOVOR` (`IdUgovora`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_UGOVOR_TRENER_TRENER1`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`TRENER` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`UGOVOR_IGRAC`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`UGOVOR_IGRAC` (
  `IdUgovora` INT NOT NULL,
  `JMB` CHAR(13) NOT NULL,
  PRIMARY KEY (`IdUgovora`, `JMB`),
  INDEX `fk_UGOVOR_IGRAC_UGOVOR1_idx` (`IdUgovora` ASC) VISIBLE,
  INDEX `fk_UGOVOR_IGRAC_IGRAC1_idx` (`JMB` ASC) VISIBLE,
  CONSTRAINT `fk_UGOVOR_IGRAC_UGOVOR1`
    FOREIGN KEY (`IdUgovora`)
    REFERENCES `db_fudbalska_liga_srbije`.`UGOVOR` (`IdUgovora`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_UGOVOR_IGRAC_IGRAC1`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`IGRAC` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`UTAKMICA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`UTAKMICA` (
  `IdKlubaD` INT NOT NULL,
  `IdKlubaG` INT NOT NULL,
  `VrijemeOdigravanaja` DATETIME NOT NULL,
  `BrojKola` INT NOT NULL,
  `IdUtakmice` INT NOT NULL,
  `BrojGolovaDomacin` INT NULL,
  `BrojGolovaGost` INT NULL,
  PRIMARY KEY (`IdUtakmice`),
  INDEX `fk_utakmica_klub_gost_idx` (`IdKlubaG` ASC) VISIBLE,
  CONSTRAINT `fk_utakmica_klub_domacin`
    FOREIGN KEY (`IdKlubaD`)
    REFERENCES `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (`IdKluba`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_utakmica_klub_gost`
    FOREIGN KEY (`IdKlubaG`)
    REFERENCES `db_fudbalska_liga_srbije`.`FUDBALSKI_KLUB` (`IdKluba`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`DETALJI_UTAKMICE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`DETALJI_UTAKMICE` (
  `IdUtakmice` INT NOT NULL,
  `JMB` CHAR(13) NOT NULL,
  `IgraOdMinute` TINYINT NOT NULL,
  `IgraoDoMinute` TINYINT NOT NULL,
  PRIMARY KEY (`IdUtakmice`, `JMB`),
  INDEX `fk_detalji_igrac_idx` (`JMB` ASC) VISIBLE,
  CONSTRAINT `fk_DETALJI_UTAKMICE_IGRAJU1`
    FOREIGN KEY (`IdUtakmice`)
    REFERENCES `db_fudbalska_liga_srbije`.`UTAKMICA` (`IdUtakmice`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalji_igrac`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`IGRAC` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`SUDI`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`SUDI` (
  `IdUtakmice` INT NOT NULL,
  `JMB` CHAR(13) NOT NULL,
  `IdPozicijeSudije` INT NOT NULL,
  PRIMARY KEY (`IdUtakmice`, `JMB`, `IdPozicijeSudije`),
  INDEX `fk_sudija_sudi_idx` (`JMB` ASC) VISIBLE,
  INDEX `fk_pozicija_sudi_idx` (`IdPozicijeSudije` ASC) VISIBLE,
  CONSTRAINT `fk_utakmica_sudi`
    FOREIGN KEY (`IdUtakmice`)
    REFERENCES `db_fudbalska_liga_srbije`.`UTAKMICA` (`IdUtakmice`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_sudija_sudi`
    FOREIGN KEY (`JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`SUDIJA` (`JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_pozicija_sudi`
    FOREIGN KEY (`IdPozicijeSudije`)
    REFERENCES `db_fudbalska_liga_srbije`.`POZICIJA_SUDIJE` (`IdPozicijeSudije`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`NALOG`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`NALOG` (
  `IdNaloga` INT NOT NULL,
  `KorisnickoIme` VARCHAR(20) NOT NULL,
  `Lozinka` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`IdNaloga`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`TIP_DOGADJAJA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`TIP_DOGADJAJA` (
  `IdDogadjaja` INT NOT NULL,
  `Opis` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`IdDogadjaja`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db_fudbalska_liga_srbije`.`DOGADJAJ`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db_fudbalska_liga_srbije`.`DOGADJAJ` (
  `IdDogadjaja` INT NOT NULL,
  `MinutDogadjaja` TIME NOT NULL,
  `IdUtakmice` INT NOT NULL,
  `JMB` CHAR(13) NOT NULL,
  PRIMARY KEY (`IdDogadjaja`, `IdUtakmice`, `JMB`),
  INDEX `fk_DOGADJAJ_DETALJI_UTAKMICE1_idx` (`IdUtakmice` ASC, `JMB` ASC) VISIBLE,
  CONSTRAINT `fk_DOGADJAJ_TIP_DOGADJAJA1`
    FOREIGN KEY (`IdDogadjaja`)
    REFERENCES `db_fudbalska_liga_srbije`.`TIP_DOGADJAJA` (`IdDogadjaja`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DOGADJAJ_DETALJI_UTAKMICE1`
    FOREIGN KEY (`IdUtakmice` , `JMB`)
    REFERENCES `db_fudbalska_liga_srbije`.`DETALJI_UTAKMICE` (`IdUtakmice` , `JMB`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
